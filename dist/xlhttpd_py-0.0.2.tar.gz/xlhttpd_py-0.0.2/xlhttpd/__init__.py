# xlhttpd_py/__init__.py

""" web server for XLattice """

__version__ = '0.0.2'
__version_date__ = '2017-03-29'

__all__ = ['__version__', '__version_date__']
